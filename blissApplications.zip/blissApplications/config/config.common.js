/**
 * Define here all default values for config elements
 */

var config = {
    
    debug: false,       // if false, log writting will be disabled
    
};