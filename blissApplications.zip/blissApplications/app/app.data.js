$(function (app, $, _, undefined) {

    _.extend(app, {
    	url : "https://private-bbbe9-blissrecruitmentapi.apiary-mock.com"
    });

}(window.app = window.app || {}, jQuery, _));