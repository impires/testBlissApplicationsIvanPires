$( function(app, $, _, undefined) {

    app.collections.Questions = app.collections.Base.PagedCollection.extend({

        model : app.models.Question,

        url : function() {
            return app.url + '/questions?offset=' + this.offset + '&limit=' + this.limit;
        },

        parse: function(response) {
            return response;
        }
        
    });

}(window.app = window.app || {}, jQuery, _));